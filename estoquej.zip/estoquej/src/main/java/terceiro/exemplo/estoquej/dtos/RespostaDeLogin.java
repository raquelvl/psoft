package terceiro.exemplo.estoquej.dtos;

public class RespostaDeLogin {
	public String token;

	public RespostaDeLogin(String token) {
		this.token = token;
	}
}